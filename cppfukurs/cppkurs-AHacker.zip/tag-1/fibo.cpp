/**
 * Aufgabenblatt 1
 * Author: André Hacker
 */

#include "fibo.hpp"
// 
// fib(n) = fib(n-1) + fib(n-2)
// fib(1) = 1
// fib(0) = 0
// 


int Fib<0>::val = 0;

int Fib<1>::val = 1;
