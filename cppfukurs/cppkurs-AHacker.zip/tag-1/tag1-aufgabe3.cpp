/**
 * Aufgabenblatt 1
 * Author: André Hacker
 */

#include "tag1-aufgabe3.hpp"

// This is the definition and declartion of the static member
template <typename T>
int Test<T>::mVal = 1000;
